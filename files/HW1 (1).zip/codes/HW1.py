# HomeWork 1
# DeadLine : 12:00 PM 12 Mehr 1398
# Total points : 100 pts
import cv2
import matplotlib.pyplot as plt
import os

# PART 4
# Implement this function so that calculate histogram from image. 
# And show it with DrawHist helper function.
# Point : 35 pts
def CalcHist(ImagePath):
    #Write your code here
    return

def DrawHist(hist):
	plt.stem(hist, use_line_collection=True)
	plt.show()

# Now Run Functions
hist = CalcHist(os.path.join('..', 'images', 'gray.jpg'))
DrawHist(hist)